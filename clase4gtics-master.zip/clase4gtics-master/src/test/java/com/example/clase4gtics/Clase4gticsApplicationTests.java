package com.example.clase4gtics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase4gticsApplicationTests {

    @Test
    void contextLoads() {
    }

}
