package com.example.clase4gtics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase4gticsApplication {

    public static void main(String[] args) {
        SpringApplication.run(Clase4gticsApplication.class, args);
    }

}
